# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('GOOG.csv')

# Plotting the histogram of closing prices
ggplot(df, aes(x=Close)) +
  geom_histogram(binwidth=10, fill="blue", color="black") +
  labs(title="Histogram of Google Stock Closing Prices", x="Close Price", y="Frequency") +
  theme_minimal()

###1
# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('GOOG.csv')

# Plotting the histogram of closing prices with a density line
ggplot(df, aes(x = Close)) +
  geom_histogram(binwidth = 10, fill = "blue", color = "black", alpha = 0.7) +
  geom_density(aes(y = ..count..), color = "red", size = 1) + # Add density line
  labs(title = "Customization: Add Density Line",
       x = "Close Price",
       y = "Frequency") +
  theme_minimal()

###2
# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('GOOG.csv')

# Plotting the histogram of closing prices with custom bin width and colors
ggplot(df, aes(x = Close)) +
  geom_histogram(binwidth = 5, fill = "skyblue", color = "darkblue") + # Custom bin width and colors
  labs(title = "Customization: Add Custom Bin Width and Colors",
       x = "Close Price",
       y = "Frequency") +
  theme_minimal()
