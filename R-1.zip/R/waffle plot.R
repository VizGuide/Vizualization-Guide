# Load necessary libraries
library(waffle)
library(dplyr)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
status_counts <- df %>% count(EmploymentStatus)

# Plotting the waffle plot
waffle(parts = status_counts$n, rows = 10, 
       title = "Employment Status Distribution", 
       colors = c("#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"))

###1
# Load necessary libraries
library(waffle)
library(dplyr)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
status_counts <- df %>% count(EmploymentStatus)

# Plotting the waffle plot
# Plotting the waffle plot with a custom color palette
waffle(parts = status_counts$n, rows = 10, 
       title = "Custom Color Palette",
       colors = c("green", "red", "skyblue", "blue", "yellow"))

###2
# Load necessary libraries
library(waffle)
library(dplyr)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
status_counts <- df %>% count(EmploymentStatus)

# Plotting the waffle plot with adjusted rows and a label for each section
waffle(parts = status_counts$n, rows = 8, 
       title = "Adjusted Rows and Section Labels",
       colors = c("#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"),
       legend_pos = "bottom")
