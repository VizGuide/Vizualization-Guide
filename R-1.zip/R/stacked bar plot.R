# Install and load necessary packages
install.packages("ggplot2")
library(ggplot2)

# Load the HR dataset
hr_data <- read.csv("HRDataset_v14.csv")

# Create a table for the plot
performance_department <- table(hr_data$DeptID, hr_data$PerfScoreID)

# Convert the table to a data frame
performance_department_df <- as.data.frame(performance_department)
colnames(performance_department_df) <- c("DeptID", "PerfScoreID", "Count")

# Create the stacked bar plot
ggplot(data = performance_department_df, aes(x = as.factor(DeptID), y = Count, fill = as.factor(PerfScoreID))) +
  geom_bar(stat = "identity") +
  labs(title = "Performance Scores by Department",
       x = "Department ID",
       y = "Count of Employees",
       fill = "Performance Score") +
  theme_minimal()

###1
# Install and load necessary packages
install.packages("ggplot2")
library(ggplot2)

# Load the HR dataset
hr_data <- read.csv("HRDataset_v14.csv")

# Create a table for the plot
performance_department <- table(hr_data$DeptID, hr_data$PerfScoreID)

# Convert the table to a data frame
performance_department_df <- as.data.frame(performance_department)
colnames(performance_department_df) <- c("DeptID", "PerfScoreID", "Count")

# Create the stacked bar plot with custom color palette
ggplot(data = performance_department_df, aes(x = as.factor(DeptID), y = Count, fill = as.factor(PerfScoreID))) +
  geom_bar(stat = "identity") +
  labs(title = "Customization: Change Color Palette for Better Readability",
       x = "Department ID",
       y = "Count of Employees",
       fill = "Performance Score") +
  scale_fill_manual(values = c("red", "blue", "green", "purple")) + # Custom colors
  theme_minimal()

###2
# Install and load necessary packages
install.packages("ggplot2")
library(ggplot2)

# Load the HR dataset
hr_data <- read.csv("HRDataset_v14.csv")

# Create a table for the plot
performance_department <- table(hr_data$DeptID, hr_data$PerfScoreID)

# Convert the table to a data frame
performance_department_df <- as.data.frame(performance_department)
colnames(performance_department_df) <- c("DeptID", "PerfScoreID", "Count")

# Create the stacked bar plot with bar labels
ggplot(data = performance_department_df, aes(x = as.factor(DeptID), y = Count, fill = as.factor(PerfScoreID))) +
  geom_bar(stat = "identity") +
  labs(title = "Customization: Add Exact Count Labels on Top of Bars",
       x = "Department ID",
       y = "Count of Employees",
       fill = "Performance Score") +
  theme_minimal() +
  geom_text(aes(label = Count), position = position_stack(vjust = 0.5), color = "black")
