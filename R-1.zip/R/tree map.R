# Load necessary libraries
library(treemap)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
agg_data <- as.data.frame(table(df$Department, df$Position))
colnames(agg_data) <- c('Department', 'Position', 'Count')

# Plotting the treemap
treemap(agg_data,
        index=c('Department', 'Position'),
        vSize='Count',
        title='Treemap of Departments and Positions',
        palette='Set3')

###1
# Load necessary libraries
library(treemap)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
agg_data <- as.data.frame(table(df$Department, df$Position))
colnames(agg_data) <- c('Department', 'Position', 'Count')

# Plotting the treemap with a different color palette and borders
treemap(
  agg_data,
  index = c('Department', 'Position'),
  vSize = 'Count',
  title = 'Customization: Change Color Palette',
  palette = 'Paired',   # Changed color palette
  border.col = 'white'  # Added borders
)

###2
# Load necessary libraries
library(treemap)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
agg_data <- as.data.frame(table(df$Department, df$Position))
colnames(agg_data) <- c('Department', 'Position', 'Count')

# Plotting the treemap with a different color palette and borders
treemap(
  agg_data,
  index = c('Department', 'Position'),
  vSize = 'Count',
  title = 'Customization: Add Borders',
  palette = 'Paired',   # Changed color palette
  border.col = 'black'  # Added borders
)

