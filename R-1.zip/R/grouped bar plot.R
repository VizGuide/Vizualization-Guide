# Load necessary library
library(ggplot2)

# Read the dataset
hr_dataset <- read.csv('HRDataset_v14.csv')

# Convert gender to factor for proper labeling
hr_dataset$Gender <- factor(hr_dataset$Gender, labels=c("Male", "Female"))

# Create the grouped bar plot
ggplot(hr_dataset, aes(x=PerformanceScore, fill=Gender)) +
  geom_bar(position="dodge") +
  scale_fill_manual(values=c("skyblue", "orange")) +
  labs(title='Performance Scores by Gender', x='Performance Score', y='Count', fill='Gender') +
  theme_minimal()

###1
# Load necessary library
library(ggplot2)

# Read the dataset
hr_dataset <- read.csv('HRDataset_v14.csv')

# Convert gender to factor for proper labeling
hr_dataset$Gender <- factor(hr_dataset$Gender, labels=c("Male", "Female"))

# Create the grouped bar plot with customized axis text and title appearance
ggplot(hr_dataset, aes(x=PerformanceScore, fill=Gender)) +
  geom_bar(position="dodge") +
  scale_fill_manual(values=c("skyblue", "orange")) +
  labs(title='Customization: Customize Axis Text and Title Appearance', x='Performance Score', y='Count', fill='Gender') +
  theme_minimal() +
  theme(
    plot.title = element_text(size=16, face="bold", family="serif"),
    axis.title.x = element_text(size=14, face="italic", family="serif"),
    axis.title.y = element_text(size=14, face="italic", family="serif"),
    axis.text.x = element_text(size=12, angle=45, hjust=1, family="serif"),
    axis.text.y = element_text(size=12, family="serif")
  )

###2
# Load necessary library
library(ggplot2)

# Read the dataset
hr_dataset <- read.csv('HRDataset_v14.csv')

# Convert gender to factor for proper labeling
hr_dataset$Gender <- factor(hr_dataset$Gender, labels=c("Male", "Female"))

# Create the grouped bar plot with customized legend
ggplot(hr_dataset, aes(x=PerformanceScore, fill=Gender)) +
  geom_bar(position="dodge") +
  scale_fill_manual(values=c("skyblue", "orange")) +
  labs(title='Customization: Change Legend Position and Appearance', x='Performance Score', y='Count', fill='Gender') +
  theme_minimal() +
  theme(
    legend.position = "bottom", # Move legend to bottom
    legend.title = element_text(size=12, face="bold"),
    legend.text = element_text(size=10)
  )
