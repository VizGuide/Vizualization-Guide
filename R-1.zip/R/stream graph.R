# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('GOOG.csv')
df$Date <- as.Date(df$Date)

# Create a stream-like effect by adding random noise
set.seed(42)
stream_data <- df$Close + rnorm(nrow(df), 0, 5)

# Plotting the stream graph
ggplot(df, aes(x=Date, y=stream_data)) +
  geom_area(fill="skyblue", alpha=0.6) +
  geom_line(color="Slateblue", alpha=0.6) +
  labs(title="Simulated Stream Graph of Google Stock Closing Prices", x="Date", y="Simulated Closing Price") +
  theme_minimal()

###1
# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('GOOG.csv')
df$Date <- as.Date(df$Date)

# Create a stream-like effect by adding random noise
set.seed(42)
stream_data <- df$Close + rnorm(nrow(df), 0, 5)

# Plotting the stream graph with smoother and custom appearance
ggplot(df, aes(x=Date, y=stream_data)) +
  geom_area(fill="skyblue", alpha=0.6) +
  geom_line(color="Slateblue", alpha=0.6) +
  geom_smooth(method="loess", span=0.2, color="darkred", size=1) +  # Add loess smoother
  labs(title="Customization: Add Smoother and Customize the Appearance",
       x="Date", y="Simulated Closing Price") +
  theme_minimal() +
  theme(
    plot.title = element_text(size=12),
    axis.title = element_text(size=14),
    axis.text = element_text(size=12)
  )

###2
# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('GOOG.csv')
df$Date <- as.Date(df$Date)

# Create a stream-like effect by adding random noise
set.seed(42)
stream_data <- df$Close + rnorm(nrow(df), 0, 5)

# Create a period column
df$Period <- ifelse(df$Date < as.Date("2022-01-01"), "Before 2022", "After 2022")

# Plotting the stream graph with facets
ggplot(df, aes(x=Date, y=stream_data)) +
  geom_area(fill="skyblue", alpha=0.6) +
  geom_line(color="Slateblue", alpha=0.6) +
  facet_wrap(~Period, scales="free_x") +  # Add facets
  labs(title="Customization: Add Facet for Different Periods",
       x="Date", y="Simulated Closing Price") +
  theme_minimal() +
  theme(
    plot.title = element_text(size=16, face="bold"),
    axis.title = element_text(size=14),
    axis.text = element_text(size=12)
  )
