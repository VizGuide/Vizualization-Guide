# Load necessary libraries
library(GGally)
library(ggplot2)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Select relevant numeric columns for the parallel plot
selected_columns <- hr_df[, c("EmpID", "Salary", "EmpSatisfaction", "Absences")]

# Create parallel plot
ggparcoord(selected_columns,
           columns = 2:4,  # Columns to be included in the plot
           groupColumn = 1,  # Column used to group the data (e.g., EmpID)
           scale = "globalminmax",
           alphaLines = 0.3) +
  labs(title = "Parallel Coordinate Plot of HR Dataset",
       x = "Variables",
       y = "Values") +
  theme_minimal()

###1
# Load necessary libraries
library(GGally)
library(ggplot2)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Select relevant numeric columns for the parallel plot
selected_columns <- hr_df[, c("EmpID", "Salary", "EmpSatisfaction", "Absences")]

# Create parallel plot with adjusted line opacity and grid lines
ggparcoord(selected_columns,
           columns = 2:4,  # Columns to be included in the plot
           groupColumn = 1,  # Column used to group the data (e.g., EmpID)
           scale = "globalminmax",
           alphaLines = 0.3) +  # Adjust line opacity
  labs(title = "Customization: Adjust Line Opacity and Add Grid Lines",
       x = "Variables",
       y = "Values") +
  theme_minimal() +
  theme(panel.grid.major = element_line(color = "grey", size = 0.5, linetype = "dashed"),
        panel.grid.minor = element_line(color = "lightgrey", size = 0.25, linetype = "dotted"))

###2
# Load necessary libraries
library(GGally)
library(ggplot2)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Select relevant numeric columns for the parallel plot
selected_columns <- hr_df[, c("EmpID", "Salary", "EmpSatisfaction", "Absences")]

# Create parallel plot with different line types for groups
ggparcoord(selected_columns,
           columns = 2:4,  # Columns to be included in the plot
           groupColumn = 1,  # Column used to group the data (e.g., EmpID)
           scale = "globalminmax",
           alphaLines = 0.5) +  # Increase line opacity
  labs(title = "Customization: Highlight Specific Groups with Different Line Types",
       x = "Variables",
       y = "Values") +
  theme_minimal() +
  scale_linetype_manual(values = c("solid", "dashed", "dotted", "dotdash")) + # Different line types
  theme(legend.position = "right") # Place the legend on the right