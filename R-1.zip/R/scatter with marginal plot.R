# Load necessary libraries
library(ggplot2)
library(ggExtra)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create scatter plot
scatter_plot <- ggplot(hr_df, aes(x = EmpSatisfaction, y = Salary)) +
  geom_point(alpha = 0.5) +
  labs(title = "Scatter Plot of Salary vs. Employee Satisfaction",
       x = "Employee Satisfaction",
       y = "Salary") +
  theme_minimal()

# Add marginal histograms
ggMarginal(scatter_plot, type = "histogram")

###1
# Load necessary libraries
library(ggplot2)
library(ggExtra)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create scatter plot
scatter_plot <- ggplot(hr_df, aes(x = EmpSatisfaction, y = Salary)) +
  geom_point(alpha = 0.5) +
  labs(title = "Customization: Use Density Plots Instead of Histograms",
       x = "Employee Satisfaction",
       y = "Salary") +
  theme_minimal()

# Add marginal histograms
ggMarginal(scatter_plot, type = "density")


###2
# Load necessary libraries
library(ggplot2)
library(ggExtra)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create scatter plot
scatter_plot <- ggplot(hr_df, aes(x = EmpSatisfaction, y = Salary)) +
  geom_point(alpha = 0.5) +
  labs(title = "Customization: Use Different Color",
       x = "Employee Satisfaction",
       y = "Salary") +
  theme_minimal()

# Add marginal histograms
ggMarginal(scatter_plot, type = "histogram", color="yellow")