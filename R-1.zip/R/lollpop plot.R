# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
status_counts <- as.data.frame(table(df$EmploymentStatus))
colnames(status_counts) <- c('EmploymentStatus', 'Count')

# Plotting the lollipop plot
ggplot(status_counts, aes(x=EmploymentStatus, y=Count)) +
  geom_segment(aes(x=EmploymentStatus, xend=EmploymentStatus, y=0, yend=Count), color="skyblue") +
  geom_point(color="blue", size=5) +
  labs(title="Count of Employees by Employment Status", x="Employment Status", y="Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


###1
# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
status_counts <- as.data.frame(table(df$EmploymentStatus))
colnames(status_counts) <- c('EmploymentStatus', 'Count')

# Plotting the lollipop plot with customized colors and data labels
ggplot(status_counts, aes(x = EmploymentStatus, y = Count)) +
  geom_segment(aes(x = EmploymentStatus, xend = EmploymentStatus, y = 0, yend = Count), color = "darkblue") +
  geom_point(color = "darkred", size = 6) +
  geom_text(aes(label = Count), vjust = -0.5, color = "black", size = 4) + # Add data labels
  labs(title = "Customization: Customize Lollipop Colors and Add Data Labels",
       x = "Employment Status",
       y = "Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 12),
        axis.title = element_text(size = 14, face = "bold"))

###2
# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
status_counts <- as.data.frame(table(df$EmploymentStatus))
colnames(status_counts) <- c('EmploymentStatus', 'Count')

# Plotting the lollipop plot with custom background color and modified axis text
ggplot(status_counts, aes(x = EmploymentStatus, y = Count)) +
  geom_segment(aes(x = EmploymentStatus, xend = EmploymentStatus, y = 0, yend = Count), color = "skyblue") +
  geom_point(color = "blue", size = 5) +
  labs(title = "Customization:Add Custom Background Color and Modify Axis Text",
       x = "Employment Status",
       y = "Count") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 12),
    axis.title = element_text(size = 14, face = "bold"),
    plot.background = element_rect(fill = "lightgrey", color = NA), # Custom background color
    panel.background = element_rect(fill = "white")
  )
