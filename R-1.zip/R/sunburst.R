# Load necessary libraries
library(sunburstR)
library(dplyr)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create a hierarchy of Department -> PerformanceScore -> RecruitmentSource
hr_df <- hr_df %>%
  mutate(DeptID = as.factor(DeptID),
         PerformanceScore = as.factor(PerformanceScore),
         RecruitmentSource = as.factor(RecruitmentSource)) %>%
  count(DeptID, PerformanceScore, RecruitmentSource)

# Create the hierarchical path
hr_df$path <- paste(hr_df$DeptID, hr_df$PerformanceScore, hr_df$RecruitmentSource, sep = "-")

# Create the sunburst plot
sunburst(
  data = hr_df %>%
    select(path, n),
  count = TRUE,
)

###1
# Load necessary libraries
library(sunburstR)
library(dplyr)
library(htmlwidgets)
library(htmltools)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create a hierarchy of Department -> PerformanceScore -> RecruitmentSource
hr_df <- hr_df %>%
  mutate(DeptID = as.factor(DeptID),
         PerformanceScore = as.factor(PerformanceScore),
         RecruitmentSource = as.factor(RecruitmentSource)) %>%
  count(DeptID, PerformanceScore, RecruitmentSource)

# Create the hierarchical path
hr_df$path <- paste(hr_df$DeptID, hr_df$PerformanceScore, hr_df$RecruitmentSource, sep = "-")

# Create the sunburst plot
plot <- sunburst(
  data = hr_df %>%
    select(path, n),
  count = FALSE,
  width = "100%",  # Adjust width
  height = "300px"  # Adjust height
)

# Add title, customize background color, and adjust size
plot_with_customizations <- htmlwidgets::prependContent(
  plot,
  tags$div(
    tags$h1("Customization: Adjust Size of the Sunburst Plot", style = "text-align: center;"),
    style = "background-color: #f0f0f0; padding: 20px; width: 100%; height: 30px; box-sizing: border-box;"
  )
)

# Print the plot with title, background color, and size adjustments
plot_with_customizations


###2
# Load necessary libraries
library(sunburstR)
library(dplyr)
library(htmlwidgets)
library(htmltools)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create a hierarchy of Department -> PerformanceScore -> RecruitmentSource
hr_df <- hr_df %>%
  mutate(DeptID = as.factor(DeptID),
         PerformanceScore = as.factor(PerformanceScore),
         RecruitmentSource = as.factor(RecruitmentSource)) %>%
  count(DeptID, PerformanceScore, RecruitmentSource)

# Create the hierarchical path
hr_df$path <- paste(hr_df$DeptID, hr_df$PerformanceScore, hr_df$RecruitmentSource, sep = "-")

# Create the sunburst plot
plot <- sunburst(
  data = hr_df %>%
    select(path, n),
  count = TRUE
)

# Add a title and customize background color
plot_with_title_and_bg <- htmlwidgets::prependContent(
  plot,
  tags$div(
    tags$h1("Customization 2: Add Legends", style = "text-align: center;"),
    style = "background-color: #f0f0f0; padding: 20px;"
  )
)

# Print the plot with title and background color
plot_with_title_and_bg
