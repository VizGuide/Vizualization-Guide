# Load necessary libraries
library(packcircles)
library(ggplot2)
library(dplyr)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Summarize data to get the count of employees per department
dept_summary <- hr_df %>%
  count(DeptID) %>%
  rename(size = n)

# Generate layout for circular packing
packing <- circleProgressiveLayout(dept_summary$size, sizetype = "area")
dept_summary <- cbind(dept_summary, packing)

# Generate coordinates for drawing circles
dat.gg <- circleLayoutVertices(packing, npoints = 50)

# Create the plot
ggplot() + 
  geom_polygon(data = dat.gg, aes(x, y, group = id, fill = as.factor(id)), colour = "black", alpha = 0.6) +
  geom_text(data = dept_summary, aes(x, y, label = DeptID), size = 4, color = "black") +
  theme_void() +
  theme(legend.position = "none") +
  coord_equal() +
  labs(title = "Circular Packing of Departments")

###1
# Load necessary libraries
library(packcircles)
library(ggplot2)
library(dplyr)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Summarize data to get the count of employees per department
dept_summary <- hr_df %>%
  count(DeptID) %>%
  rename(size = n)

# Generate layout for circular packing
packing <- circleProgressiveLayout(dept_summary$size, sizetype = "area")
dept_summary <- cbind(dept_summary, packing)

# Generate coordinates for drawing circles
dat.gg <- circleLayoutVertices(packing, npoints = 50)

# Create the plot with adjusted colors and legend
ggplot() + 
  geom_polygon(data = dat.gg, aes(x, y, group = id, fill = as.factor(id)), colour = "black", alpha = 0.6) +
  geom_text(data = dept_summary, aes(x, y, label = DeptID), size = 4, color = "black") +
  theme_void() +
  theme(legend.position = "right") +   # Added legend position
  scale_fill_brewer(palette = "Set3") +  # Custom color palette
  coord_equal() +
  labs(title = "Customization: Adjust Colors and Add a Legend", fill = "Department ID")

###2
# Load necessary libraries
library(packcircles)
library(ggplot2)
library(dplyr)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Summarize data to get the count of employees per department
dept_summary <- hr_df %>%
  count(DeptID) %>%
  rename(size = n)

# Generate layout for circular packing
packing <- circleProgressiveLayout(dept_summary$size, sizetype = "area")
dept_summary <- cbind(dept_summary, packing)

# Generate coordinates for drawing circles
dat.gg <- circleLayoutVertices(packing, npoints = 50)

# Create the plot with adjusted circle sizes and border styles
ggplot() + 
  geom_polygon(data = dat.gg, aes(x, y, group = id, fill = as.factor(id)), colour = "grey30", size = 0.5, alpha = 0.8) +
  geom_text(data = dept_summary, aes(x, y, label = DeptID), size = 4, color = "black") +
  theme_void() +
  theme(legend.position = "none") +
  coord_equal() +
  labs(title = "Customization: Change Circle Sizes and Border Styles
")
