# Load necessary libraries
library(ggplot2)
library(hexbin)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Plotting the hexbin plot
ggplot(data=df, aes(x=Salary, y=EngagementSurvey)) +
  geom_hex(bins=30) +
  scale_fill_viridis_c() +
  labs(title="Hexbin Plot of Salary vs. Engagement Survey", x="Salary", y="Engagement Survey", fill="Count") +
  theme_minimal()

###1
# Load necessary libraries
library(ggplot2)
library(hexbin)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Define specific values to highlight
highlight_points <- df[df$Salary > 100000 & df$EngagementSurvey > 4, ]

# Plotting the hexbin plot with highlighted points and customized appearance
ggplot(data=df, aes(x=Salary, y=EngagementSurvey)) +
  geom_hex(bins=30) +
  geom_point(data=highlight_points, aes(x=Salary, y=EngagementSurvey), color="red", size=3) +  # Add points for specific values
  scale_fill_viridis_c() +
  labs(title="Customization 2: Add Points for Specific Values and Customize Appearance", 
       x="Salary", y="Engagement Survey", fill="Count") +
  theme_minimal() +
  theme(
    plot.title = element_text(size=12),
    axis.title = element_text(size=12),
    axis.text = element_text(size=12)
  )

###2
# Load necessary libraries
library(ggplot2)
library(hexbin)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Plotting the hexbin plot with a smoother line and customized legend
ggplot(data=df, aes(x=Salary, y=EngagementSurvey)) +
  geom_hex(bins=30) +
  geom_smooth(method="lm", color="blue", se=FALSE) +  # Add smoother line
  scale_fill_viridis_c() +
  labs(title="Customization: Add Smoother Line and Customize Legend", 
       x="Salary", y="Engagement Survey", fill="Count") +
  guides(fill=guide_legend(title="Number of Employees")) +  # Customize legend title
  theme_minimal() +
  theme(
    plot.title = element_text(size=14),
    axis.title = element_text(size=14),
    axis.text = element_text(size=12)
  )
