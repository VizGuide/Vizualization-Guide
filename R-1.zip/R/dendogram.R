# Load necessary libraries
library(ggplot2)
library(ggdendro)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Encode categorical variables
df$Department <- as.numeric(as.factor(df$Department))
df$Position <- as.numeric(as.factor(df$Position))

# Create a hierarchical clustering model
hc <- hclust(dist(df[, c('Department', 'Position')]), method = 'ward.D2')

# Plotting the dendrogram
ggdendrogram(hc, rotate = TRUE, size = 3) + 
  labs(title = 'Dendrogram of Departments and Positions', x = 'Position', y = 'Distance')

###1
# Load necessary libraries
library(ggplot2)
library(ggdendro)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Encode categorical variables
df$Department <- as.numeric(as.factor(df$Department))
df$Position <- as.numeric(as.factor(df$Position))

# Create a hierarchical clustering model
hc <- hclust(dist(df[, c('Department', 'Position')]), method = 'ward.D2')

# Plotting the dendrogram with customized branch colors
ggdendrogram(hc, rotate = TRUE, size = 3) + 
  labs(title = 'Dendrogram with Custom Branch Colors', x = 'Position', y = 'Distance') +
  theme(axis.text.y = element_text(color = 'blue'))

###2
# Load necessary libraries
library(ggplot2)
library(ggdendro)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Encode categorical variables
df$Department <- as.numeric(as.factor(df$Department))
df$Position <- as.numeric(as.factor(df$Position))

# Create a hierarchical clustering model
hc <- hclust(dist(df[, c('Department', 'Position')]), method = 'ward.D2')

# Convert dendrogram data to a data frame for customization
dendro_data <- ggdendro::dendro_data(hc, type = "rectangle")

# Plotting the dendrogram with a color gradient on leaves
ggplot(dendro_data$segments, aes(x = x, y = y, color = y)) +
  geom_segment(aes(xend = xend, yend = yend), size = 2) +
  scale_color_gradient(low = "blue", high = "red") +
  labs(title = 'Dendrogram with Color Gradient on Leaves', x = 'Position', y = 'Distance') +
  theme_minimal()

