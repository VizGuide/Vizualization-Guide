# Load necessary libraries
library(VennDiagram)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Create sets for demonstration purposes
dept_set <- unique(na.omit(df$Department))
position_set <- unique(na.omit(df$Position))

# Plotting the Venn diagram
venn.plot <- draw.pairwise.venn(area1=length(dept_set), area2=length(position_set),
                                cross.area=length(intersect(dept_set, position_set)),
                                category=c("Departments", "Positions"),
                                fill=c("lightblue", "lightgreen"))

grid.draw(venn.plot)

###1
# Load necessary libraries
library(VennDiagram)
library(grid)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Create sets for demonstration purposes
dept_set <- unique(na.omit(df$Department))
position_set <- unique(na.omit(df$Position))

# Plotting the Venn diagram with custom colors and transparency
venn.plot <- draw.pairwise.venn(area1 = length(dept_set), 
                                area2 = length(position_set),
                                cross.area = length(intersect(dept_set, position_set)),
                                category = c("Departments", "Positions"),
                                fill = c("lightblue", "lightgreen"),
                                alpha = c(0.5, 0.5),
                                cat.pos = c(0, 0),
                                cat.dist = c(0.03, 0.03),
                                cat.cex = 1.5,
                                cat.col = c("darkblue", "darkgreen"))

# Draw the Venn diagram
grid.draw(venn.plot)

# Add a title
grid.text("Customization: Add Custom Colors and Adjust Transparency", x = 0.5, y = 0.95, gp = gpar(fontsize = 14))

###2
# Load necessary libraries
library(VennDiagram)
library(grid)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Create sets for demonstration purposes
dept_set <- unique(na.omit(df$Department))
position_set <- unique(na.omit(df$Position))

# Plotting the Venn diagram with adjusted font size and style for labels
venn.plot <- draw.pairwise.venn(area1 = length(dept_set), 
                                area2 = length(position_set),
                                cross.area = length(intersect(dept_set, position_set)),
                                category = c("Departments", "Positions"),
                                fill = c("lightblue", "lightgreen"),
                                alpha = c(0.5, 0.5),
                                label.col = c("darkblue", "darkgreen", "black"),
                                cat.pos = c(0, 0),
                                cat.dist = c(0.03, 0.03),
                                cat.cex = 1.5,
                                cat.col = c("darkblue", "darkgreen"),
                                fontfamily = "serif",
                                cex = 2)

# Draw the Venn diagram
grid.draw(venn.plot)

# Add a title
grid.text("Customization: Adjust Font Size and Style for Labels", 
          x = 0.5, 
          y = 1.05, 
          gp = gpar(fontsize = 14))
