# Load necessary library
library(ggplot2)

# Read the dataset
hr_dataset <- read.csv('HRDataset_v14.csv')

# Create the bar plot
ggplot(hr_dataset, aes(x=PerformanceScore)) +
  geom_bar(fill='skyblue') +
  labs(title='Distribution of Performance Scores', x='Performance Score', y='Count') +
  theme_minimal()

###bar1
# Load necessary library
library(ggplot2)

# Read the dataset
hr_dataset <- read.csv('HRDataset_v14.csv')

# Create the bar plot with custom color palette
ggplot(hr_dataset, aes(x=PerformanceScore)) +
  geom_bar(aes(fill=PerformanceScore)) +
  scale_fill_manual(values=c("red", "green", "blue", "purple")) + # Custom colors
  labs(title='Change Bar Colors for Better Readability', x='Performance Score', y='Count') +
  theme_minimal()


###bar2
# Load necessary library
library(ggplot2)

# Read the dataset
hr_dataset <- read.csv('HRDataset_v14.csv')

# Create the bar plot with custom grid lines
ggplot(hr_dataset, aes(x=PerformanceScore)) +
  geom_bar(fill='skyblue') +
  labs(title='Customize Color and Style of Grid Lines', x='Performance Score', y='Count') +
  theme_minimal() +
  theme(panel.grid.major = element_line(color = "grey", size = 0.5, linetype = "dashed"),
        panel.grid.minor = element_line(color = "lightgrey", size = 0.25, linetype = "dotted"))
