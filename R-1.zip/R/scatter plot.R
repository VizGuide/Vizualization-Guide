# Load necessary libraries
library(ggplot2)

# Read the dataset
goog_df <- read.csv("GOOG.csv")

# Create scatter plot
ggplot(goog_df, aes(x = Volume, y = Close)) +
  geom_point() +
  labs(title = "Scatter Plot of Google Stock Prices",
       x = "Volume",
       y = "Close Price") +
  theme_minimal()

###scatter1
# Load necessary libraries
library(ggplot2)

# Read the dataset
goog_df <- read.csv("GOOG.csv")

# Create scatter plot with a smoothing line
ggplot(goog_df, aes(x = Volume, y = Close)) +
  geom_point(shape = 19, color = "blue", size = 3) + # Custom point shape and color
  geom_smooth(method = "loess", color = "red", se = FALSE) + # Add smoothing line
  labs(title = "Customization: Add a Smoothing Line",
       x = "Volume",
       y = "Close Price") +
  theme_minimal()

###scatter2
# Load necessary libraries
library(ggplot2)

# Read the dataset
goog_df <- read.csv("GOOG.csv")

# Create scatter plot with adjusted point transparency
ggplot(goog_df, aes(x = Volume, y = Close)) +
  geom_point(shape = 19, color = "blue", size = 3, alpha = 0.6) + # Adjust point transparency
  labs(title = "Customization: Adjust Point Transparency (Alpha)",
       x = "Volume",
       y = "Close Price") +
  theme_minimal()

