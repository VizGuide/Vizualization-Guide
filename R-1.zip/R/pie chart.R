# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
status_counts <- table(df$EmploymentStatus)

# Plotting the pie chart
pie(status_counts, labels = paste(names(status_counts), round(status_counts / sum(status_counts) * 100, 1), "%"), main="Distribution of Employment Status", col=c("lightblue", "lightgreen", "lightcoral", "lightskyblue", "lightpink"))

###1
# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
status_counts <- as.data.frame(table(df$EmploymentStatus))
colnames(status_counts) <- c("EmploymentStatus", "Count")

# Calculate the percentage
status_counts$Percentage <- round(status_counts$Count / sum(status_counts$Count) * 100, 1)

# Create the pie chart with a black border around the slices
ggplot(status_counts, aes(x = "", y = Count, fill = EmploymentStatus)) +
  geom_bar(width = 1, stat = "identity", color = "black") +
  coord_polar("y") +
  labs(title = "Customization: Add a Black Border to the Pie Slices") +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5)) +
  geom_text(aes(label = paste0(Percentage, "%")), position = position_stack(vjust = 0.5)) +
  scale_fill_manual(values = c("lightblue", "lightgreen", "lightcoral", "lightskyblue", "lightpink"))

###2
# Load necessary libraries
library(ggplot2)

# Load the dataset
df <- read.csv('HRDataset_v14.csv')

# Aggregate the data
status_counts <- as.data.frame(table(df$EmploymentStatus))
colnames(status_counts) <- c("EmploymentStatus", "Count")

# Calculate the percentage
status_counts$Percentage <- round(status_counts$Count / sum(status_counts$Count) * 100, 1)

# Create the pie chart with percentage labels inside the pie
ggplot(status_counts, aes(x = "", y = Count, fill = EmploymentStatus)) +
  geom_bar(width = 1, stat = "identity") +
  coord_polar("y") +
  labs(title = "Customization 4: Add Percentage Labels Inside the Pie") +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5)) +
  geom_text(aes(label = paste0(Percentage, "%")), position = position_stack(vjust = 0.5), color = "white", size = 4) +
  scale_fill_manual(values = c("lightblue", "lightgreen", "lightcoral", "lightskyblue", "lightpink"))
