# Load necessary libraries
library(ggplot2)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create connected scatter plot
ggplot(hr_df, aes(x = EmpID, y = Salary, color = factor(EmpSatisfaction))) +
  geom_point() +
  geom_line(aes(group = 1)) +
  labs(title = "Connected Scatter Plot of Salary and EmpSatisfaction by EmpID",
       x = "Employee ID",
       y = "Salary",
       color = "Employee Satisfaction") +
  theme_minimal()


###1
# Load necessary libraries
library(ggplot2)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create connected scatter plot with custom point shape, color, and size
ggplot(hr_df, aes(x = EmpID, y = Salary, color = factor(EmpSatisfaction))) +
  geom_point(shape = 19, size = 3) + # Custom point shape and size
  geom_line(aes(group = 1), color = "grey") + # Custom line color
  labs(title = "Customization: Change Point Shape, Color, and Size",
       x = "Employee ID",
       y = "Salary",
       color = "Employee Satisfaction") +
  scale_color_manual(values = c("blue", "green", "red", "purple","green")) + # Custom point colors
  theme_minimal()

###2
# Load necessary libraries
library(ggplot2)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create connected scatter plot with custom grid lines
ggplot(hr_df, aes(x = EmpID, y = Salary, color = factor(EmpSatisfaction))) +
  geom_point(shape = 19, size = 3) + # Custom point shape and size
  geom_line(aes(group = 1), color = "grey") + # Custom line color
  labs(title = "Customization: Add Grid Lines",
       x = "Employee ID",
       y = "Salary",
       color = "Employee Satisfaction") +
  scale_color_manual(values = c("blue", "green", "red", "purple","yellow")) + # Custom point colors
  theme_minimal() +
  theme(
    panel.grid.major = element_line(color = "grey", size = 0.5, linetype = "dashed"),
    panel.grid.minor = element_line(color = "lightgrey", size = 0.25, linetype = "dotted")
  )
