# Load necessary libraries
library(ggplot2)

# Read the dataset
goog_df <- read.csv("GOOG.csv")

# Convert the Date column to Date type
goog_df$Date <- as.Date(goog_df$Date, format="%Y-%m-%d")

# Create line plot
ggplot(goog_df, aes(x = Date, y = Close)) +
  geom_line(color = "blue") +
  labs(title = "Trend of Google Closing Prices Over Time",
       x = "Date",
       y = "Closing Price") +
  theme_minimal()

###1
# Load necessary libraries
library(ggplot2)

# Read the dataset
goog_df <- read.csv("GOOG.csv")

# Convert the Date column to Date type
goog_df$Date <- as.Date(goog_df$Date, format="%Y-%m-%d")

# Create line plot with a smoothing line
ggplot(goog_df, aes(x = Date, y = Close)) +
  geom_line(color = "blue") +
  geom_smooth(method = "loess", color = "red", se = FALSE) + # Add smoothing line
  labs(title = "Customization: Add a Smoothing Line",
       x = "Date",
       y = "Closing Price") +
  theme_minimal()

###2
# Load necessary libraries
library(ggplot2)

# Read the dataset
goog_df <- read.csv("GOOG.csv")

# Convert the Date column to Date type
goog_df$Date <- as.Date(goog_df$Date, format="%Y-%m-%d")

# Define the date ranges to highlight
highlight_start <- as.Date("2020-03-01")
highlight_end <- as.Date("2020-04-01")

# Create line plot with highlighted date range
ggplot(goog_df, aes(x = Date, y = Close)) +
  geom_line(color = "blue") +
  geom_rect(aes(xmin = highlight_start, xmax = highlight_end, ymin = -Inf, ymax = Inf),
            fill = "lightblue", alpha = 0.3) + # Highlight date range
  labs(title = "Customization: Highlight Specific Date Ranges",
       x = "Date",
       y = "Closing Price") +
  theme_minimal()
