# Load necessary libraries
library(ggplot2)
library(ggExtra)
library(wordcloud)
library(RColorBrewer)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create a table of the RecruitmentSource column
recruitment_source_freq <- table(hr_df$RecruitmentSource)

# Convert the table to a data frame
recruitment_source_df <- as.data.frame(recruitment_source_freq)

# Create a word cloud
set.seed(1234)  # for reproducibility
wordcloud(words = recruitment_source_df$Var1, 
          freq = recruitment_source_df$Freq, 
          min.freq = 1,
          max.words = 200, 
          random.order = FALSE, 
          rot.per = 0.45, 
          colors = brewer.pal(8, "Dark2"))

###1
# Load necessary libraries
library(ggplot2)
library(ggExtra)
library(wordcloud)
library(RColorBrewer)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create a table of the RecruitmentSource column
recruitment_source_freq <- table(hr_df$RecruitmentSource)

# Convert the table to a data frame
recruitment_source_df <- as.data.frame(recruitment_source_freq)

# Create a word cloud with different color palettes
set.seed(1234)  # for reproducibility
wordcloud(words = recruitment_source_df$Var1, 
          freq = recruitment_source_df$Freq, 
          min.freq = 1,
          max.words = 200, 
          random.order = FALSE, 
          rot.per = 0.35, 
          colors = brewer.pal(9, "Paired"))

# Add a title to the word cloud
title(main = "Customization: Use Different Color Palettes")

###2
# Load necessary libraries
library(ggplot2)
library(ggExtra)
library(wordcloud)
library(RColorBrewer)

# Read the dataset
hr_df <- read.csv("HRDataset_v14.csv")

# Create a table of the RecruitmentSource column
recruitment_source_freq <- table(hr_df$RecruitmentSource)

# Convert the table to a data frame
recruitment_source_df <- as.data.frame(recruitment_source_freq)

# Create a word cloud with background color
set.seed(1234)  # for reproducibility
par(bg = "lightgrey")  # Set background color
wordcloud(words = recruitment_source_df$Var1, 
          freq = recruitment_source_df$Freq, 
          min.freq = 1,
          max.words = 200, 
          random.order = FALSE, 
          rot.per = 0.35, 
          colors = brewer.pal(8, "Dark2"))

# Add a title to the word cloud
title(main = "Customization: Add Background Color")